import { Component} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { ProductoService } from '../services/producto.service';
import { Producto } from '../models/producto'
import { RootRenderer } from '@angular/core/src/render/api';
import { error } from 'selenium-webdriver';

@Component({
  	selector: 'productoadd',
  	templateUrl: './productoadd.component.html',
  	providers: [ProductoService]
  
})
export class ProductoaddComponent{
  	public titulo:string;
  	public producto: Producto;

  	constructor(
		  private _productoService: ProductoService,
		  private _route: ActivatedRoute,
		  private _router:Router
	  ) {
    	this.titulo = 'Crear un nuevo producto';
    	this.producto = new Producto(0, '','',0,'');
    }

 	ngOnInit() {
      	console.log('producto-add.component cargada');
  	}

 	onSubmit() {
		  console.log(this.producto);
		  this._productoService.addProducto(this.producto).subscribe(
			  response => {
				  if (response.code == 200) {
						this._router.navigate(['/home']);
				  } else {
					  console.log(response);
				  }
			  }, 
			  error => {
				  console.log(<any>error);
			  }
		  );
	}
}


