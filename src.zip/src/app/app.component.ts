import { Component } from '@angular/core';
import { GLOBAL } from './components/services/global';
import { global } from '@angular/core/src/util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
  
})
export class AppComponent {
  public title = 'Productos angular 5';
  public header_color: string;

  constructor() {
    this.header_color = GLOBAL.header_color;
  }
}
